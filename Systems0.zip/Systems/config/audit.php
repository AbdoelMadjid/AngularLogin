<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $location = $_REQUEST['location'];
    $competency = $_REQUEST['competency'];
    $tracks = $_REQUEST['tracks'];
    $projectName = $_REQUEST['projectName'];
    $NC = $_REQUEST['NC'];
    $projectManager = $_REQUEST['projectManager'];
    $Lead = $_REQUEST['Lead'];
    $qaLead = $_REQUEST['qaLead'];
    $auditor = $_REQUEST['auditor'];
    $Customer = $_REQUEST['customer'];
    $aduitDate = $_REQUEST['aduitDate'];
     $remarks = $_REQUEST['remarks'];
    
    $track=$tracks[0];
    $question=$_REQUEST['ques'];
    $Evidence=$_REQUEST['Evidence'];
    $Verified=$_REQUEST['Verified'];
    $TotalPoints=$_REQUEST['TPoints'];
    $AttainedPoints=$_REQUEST['APoints'];
    $exception=$_REQUEST['exception'];
    $nc=$_REQUEST['nc'];
    $stages=$_REQUEST['stage'];
    $observation=$_REQUEST['observation'];
    $sumtotal_points=array_sum($TotalPoints);
    $sumattain_points=array_sum($AttainedPoints);
    $total=round(($sumattain_points/$sumtotal_points)*100);

    if(isset($_REQUEST['NonConformanceSummary'])){
    	$NonConformanceSummary = $_REQUEST['NonConformanceSummary'];
    	$type = $_REQUEST['type'];
   		$owner = $_REQUEST['owner'];
    	$phase = $_REQUEST['phase'];
    }
    if(isset($_REQUEST['Observations'])){
    	 $Observations = $_REQUEST['Observations'];
    }


    
    $query="INSERT INTO `audit`(`location`,`competency`,`tracks`,`Customer`,`projectName`,`Total_NC`,`projectManager`,`Lead`,`qaLead`,`auditor`,`aduitDate`,`remarks`) VALUES('$location','$competency','$track','$Customer','$projectName',$NC,'$projectManager','$Lead','$qaLead','$auditor','$aduitDate','$remarks')";
    $sql=mysqli_query($connect, $query);
        if($sql==true){
         $last_id = mysqli_insert_id($connect);
          $j=0;
          while($j<count($Verified)){
            $query1="INSERT INTO `check_list`(`Evidence`, `Verified`, `Total_Points`, `Points_Attained`, `Exception_Deviation`, `NC`, `Observation`, `report_id`,`question`,`sumtotal_points`,`sumattain_points`,`project_total`,`stage_id`) VALUES('$Evidence[$j]','$Verified[$j]','$TotalPoints[$j]','$AttainedPoints[$j]','$exception[$j]','$nc[$j]','$observation[$j]',$last_id,'$question[$j]',$sumtotal_points,$sumattain_points,$total,$stages[$j]);";
            
  
       
     
    if(mysqli_query($connect, $query1)==true){
    }
    else{
      echo $query1;
     }
     $j++;
}

    

			if(count($type)>=1){
          $k=0;
          while($k<count($type)){
            $query2="INSERT INTO `summary`(`NonConformanceSummary`,`type`,`owner`,`phase`,`report_id`) VALUES('$NonConformanceSummary[$k]','$type[$k]','$owner[$k]','$phase[$k]','$last_id');";
            
            $k++;
            if(mysqli_query($connect,$query2)==true){

            }else{
              echo $query2;
            }

          }}
          if(count($Observations)>=1){
          $l=0;
          while($l<count($Observations)){

                $query3="INSERT INTO `observations`(`report_id`,`Observations`) VALUES('$last_id','$Observations[$l]');";
            
            $l++;
            if(mysqli_query($connect,$query3)==true){

            }else{
              echo $query3;
            }
        }
}

        

echo "<script>alert('Report Has been added Successfully');</script>";
 echo "<script type='text/javascript'>alert('Project Total Points: {$total}');</script>";

        header("location:index");
        }
        
        else{
        echo "<script>alert('Report Not added Successfully');</script>";
        } 



   

     







}
?>
<?php 
	$databse="system";
	$host="localhost";
	$user="root";
	$password="";

	$connect=mysqli_connect($host,$user,$password,$databse);

?>
<?php 

include('config/header.php');
?>
<?php
$id=$_GET['id'];

if(isset($_POST['update'])){
    $location = $_POST['location'];
    $competency = $_POST['competency'];
    $tracks = $_POST['tracks'];
    $projectName = $_POST['projectName'];
    $projectManager = $_POST['projectManager'];
    $Lead = $_POST['Lead'];
    $qaLead = $_POST['qaLead'];
    $auditor = $_POST['auditor'];
    $Customer = $_POST['customer'];
    $aduitDate = $_POST['aduitDate'];
     $remarks = $_POST['remarks'];


    


    
    $query="UPDATE `audit` SET `location`='$location',`competency` = '$competency',`tracks` = '$tracks',`Customer` = '$Customer',`projectName` = '$projectName',`projectManager` = '$projectManager',`Lead` = '$Lead',`qaLead` = '$qaLead' ,`auditor` = '$auditor' ,`aduitDate` = '$aduitDate' ,`remarks`='$remarks' where id=$id;";
    $sql=mysqli_query($connect, $query);
        if($sql==true){

    

     

          echo "<script>alert('Report Has been Update Successfully');</script>";
 echo "<script type='text/javascript'>alert('Project Total Points: {$total}');</script>";

        header("location:view-report?id=$id");
        }
        
        else{
        echo "<script>alert('Report Not Update Successfully');</script>";
        } 



   

     







}
          ?>












<style>


  body {
  background-color: #f1f1f1;
}
  

  table{
    left:50px;
  }


 input,textarea,select,option,#dropdown{
    border: none;
    border-color: transparent;
    background-color: #f1f1f1;
    outline: none !important;
  }


input:focus, textarea:focus{

    color: #ff0000;
    background-color: #fff;
}

</style>
<?php 
if(isset($_POST['approve'])){
  echo "approve";
}elseif(isset($_POST['reject'])){
  echo "reject";
}

?>

<br/>
<br/>

  <?php 
    
$query="select * from `audit` where id=$id";
$sql=mysqli_query($connect, $query);
$rows=mysqli_num_rows($sql);
if($rows==1){
  while($row=mysqli_fetch_assoc($sql)){
    $location=$row['location'];
    $competency=$row['competency'];
    $customer=$row['Customer'];
    $track=$row['tracks'];
    $auditDate=$row['aduitDate'];
    $Project=$row['projectName'];
    $id=$row['id'];
      $projectManager=$row['projectManager'];
      $lead=$row['Lead'];
      $qalead=$row['qaLead'];
      $auditor=$row['auditor'];
      $nc=$row['Total_NC'];
      $remarks=$row['remarks'];
      $status=$row['status'];
?>
<h3 class="h3 text-center" >Audit Reports Details</h3>
<div align="right">
  <?php 
if($status==0){
  ?>

<a href="config/approve?id=<?php echo $id; ?>" onclick="return confirm('Are you sure you want to approve this Report ?');"><button type="button" class="btn waves-effect waves-light btn-success">Accept</button></a>
                                        <a href="config/reject?id=<?php echo $id; ?>" onclick="return confirm('Are you sure you want to reject this Report ?');"><button type="button" class="btn waves-effect waves-light btn-danger">Reject</button></a>
                                      <?php } ?>
</div>
<div class="container">
  <div class="row">
    <div class="col-8"></div>
    <div class="col-12">


<table  class="table text-center table-hover">
  
  <thead>
  	<form method="POST"> 
    <tr>
      <th scope="col" colspan="8" style="text-align:center;">General Information
      <input type="submit" style="float: right" class="btn btn-success" name="update" value="Update Report">
        <?php 
    $emp="SELECT * from `employees`";
    $empquery=mysqli_query($connect,$emp);
       $options = "";

            while($row2 = mysqli_fetch_array($empquery))
            {
                $options = $options."<option>$row2[2]</option>";
            }
    ?>
        
      
      <tr>
      <th scope="col" style="text-align:left">Location</th>
      <td style="text-align:left"><input type="text" name="location" value="<?php echo $location;?>"></td>
      <th scope="col" style="text-align:left">Project Manager</th>
      <td style="text-align:left">
        <select class="form-control" id="dropdown" name="projectManager">
        <option value="<?php echo $projectManager;?>" selected><?php echo $projectManager;?>
        <?php echo $options;?>
      </select>
       </td>
    <tr>
      <th scope="col" style="text-align:left">Competency</th>
      <td style="text-align:left"><input type="text" name="competency" value="<?php echo $competency;?>"></td>
      <th scope="col" style="text-align:left">Development Lead</th>
      <td style="text-align:left"><select id="dropdown" class="form-control" name="Lead">
        <option value="<?php echo $lead;?>" selected><?php echo $lead;?>
        <?php echo $options;?>
      </select></td>
      <tr>
      <th scope="col" style="text-align:left">Track</th>
		<td style="text-align:left"><input type="text" name="tracks" value="<?php echo $track;?>"></td>
	  <th scope="col" style="text-align:left">QA Lead</th>
		<td style="text-align:left">
        <select class="form-control" id="dropdown" name="qaLead">
        <option value="<?php echo $qalead;?>" selected><?php echo $qalead;?>
        <?php echo $options;?>
      </select></td>
      <tr>
      <th scope="col" style="text-align:left">Customer</th>
      <td style="text-align:left"><input type="text" name="customer" value="<?php echo $customer;?>"></td>
      <th scope="col" style="text-align:left">Auditor</th>
      <td style="text-align:left"><input type="text" name="auditor" value="<?php echo $auditor;?>"></td>
      <tr>
      <th scope="col" style="text-align:left">Project</th>
      <td style="text-align:left"><input type="text" name="projectName" value="<?php echo $Project;?>"></td>
      <th scope="col" style="text-align:left">Audit Date</th>
      <td style="text-align:left"><input type="date" name="aduitDate" value="<?php echo $auditDate;?>"></td>
      <tr>

        <?php 
          $query="select COUNT(*) as total from summary where report_id = $id";
          $tnc=mysqli_query($connect, $query);
          $ncrow=mysqli_fetch_assoc($tnc);
          $totalnc=$ncrow['total'];
        ?>
      <th scope="col" colspan="2" style="text-align:left">Number of NC </th>
      <td colspan="2" style="text-align:right"><?php echo $totalnc;?></td>
      </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr>
      </th>
     
    </tr>
    <tr>
      <th scope="col" colspan="4" style="text-align:left">Remarks</th>   
    </tr>
    <tr>
      <td colspan="4" style="text-align:left"><textarea name="remarks" rows="2" cols="150"><?php echo $remarks;?></textarea></td>      
    </tr>
  </form>
  </thead>
  
  <tbody>
 
    
  <?php	}
}
?> 
    
  </tbody>


</table>

<table class="table text-center table-hover">
  <tr>
    <?php 
    $quer01="SELECT check_list.checklist_id,check_list.project_total from check_list where check_list.report_id = $id";
 $sql01=mysqli_query($connect, $quer01);
  $rows0=mysqli_num_rows($sql01);
if($rows0>0){
    $test=mysqli_fetch_array($sql01);
      $project_total=$test['project_total'];
    
}

$query1="SELECT check_list.checklist_id, check_list.Evidence, check_list.Verified,check_list.Total_Points,check_list.Points_Attained,check_list.Exception_Deviation,check_list.NC, check_list.Observation,check_list.report_id, check_list.question,check_list.project_total from audit INNER JOIN check_list where check_list.report_id = $id && check_list.report_id = audit.id";

  $sql1=mysqli_query($connect, $query1);
  $rows=mysqli_num_rows($sql1);

    ?>
<h3 class="text-center">Project Total Score: <?php echo $project_total;?></h3>
    <th scope="col" colspan="8" style="text-align:center;">INTERNAL AUDIT CHECK LIST FOR PROJECT MANAGEMENT
      </th>
      <td><a href="report-summary?id=<?php echo $id; ?>" ><button align="left">View Summary</button></a></td>
  </tr>
  <tr>
    <th class="text-left">Sr#</th>
    <th class="text-left">Query</th>
    <th class="text-left">Possible Evidence</th>
    <th class="text-left">Verified</th>
    <th class="text-left">Total Points</th>
    <th class="text-left">Points Attained</th>
    <th class="text-left">Exception/ Deviation</th>
    <th class="text-left">NC #</th>
    <th class="text-left">Observation and Remarks</th>
  </tr>
<?php 
  
  
  $sr=0;
  if($rows>=0){
  while($row1=mysqli_fetch_assoc($sql1)){
    $question=$row1['question'];
    $Verified=$row1['Verified'];
    $Total_Points=$row1['Total_Points'];
    $Points_Attained=$row1['Points_Attained'];
    $Evidence=$row1['Evidence'];
    $Exception_Deviation=$row1['Exception_Deviation'];
    $Observation=$row1['Observation'];
    $nc=$row1['NC'];    
    $sr++;


?>
  <tr>
    <td style="text-align:left"><?php echo $sr?></td>
    <td style="text-align:left"><?php echo $question;?></td>
    <td style="text-align:left"><textarea name="Evidence[]" rows="3"><?php echo $Evidence;?></textarea></td>
    <td style="text-align:left"><input type="text" name="Verified[]" size="2" value="<?php echo $Verified;?>"></td>
    <td style="text-align:left"><input type="text" name="TPoints[]" size="2" value="<?php echo $Total_Points;?>"></td>
    <td style="text-align:left"><input type="text" name="APoints[]" size="2" value="<?php echo $Points_Attained;?>"></td>
    <td style="text-align:left"><input type="text" name="exception[]" value="<?php echo $Exception_Deviation;?>"></td>
    <td style="text-align:left"><input type="text" name="nc[]" size="2" value="<?php echo $nc;?>"></td>
    <td style="text-align:left"><textarea name="observation[]" rows="4"><?php echo $Observation;?></textarea></td>
    
 
  </tr>

  <?php 
}
}
  ?>

</table>


</div>
</div>
</div>
<div class="col-8"></div>
<br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>

<?php 
include('config/footer.php');
 ?>
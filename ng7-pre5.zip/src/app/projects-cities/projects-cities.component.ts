import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { dashboard } from '../stages';

@Component({
  selector: 'app-projects-cities',
  templateUrl: './projects-cities.component.html',
  styleUrls: ['./projects-cities.component.scss']
})
export class ProjectsCitiesComponent implements OnInit {

  constructor(private services: Service) { }
dashboard :any= [];
error;
  ngOnInit() {
    this.getloc();
  }

  title = "Projects (Cities and Number of Projects)";
  type="ColumnChart";
 

  
  columnNames = ['Cities', 'Projects'];
 
  width=500;
  height=350;
  options ={
    legend: { position: "none" }
  };

  getloc(): void{
    this.services.getloc().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
  
}

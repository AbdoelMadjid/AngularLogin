export class summaryDetail{
    NonConformanceSummary: string;
    type: string;
    owner: string;
    Observations: string;
}
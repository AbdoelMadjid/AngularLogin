import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';
import { Reports } from 'src/app/reports';

@Component({
  selector: 'app-rejectedreports',
  templateUrl: './rejectedreports.component.html',
  styleUrls: ['./rejectedreports.component.scss']
})
export class RejectedreportsComponent implements OnInit {
reports: Reports[];
error;
  constructor(private service: Service) { }

  ngOnInit() {
    this.getReports();
  }

  getReports(): void{
    this.service.getrejectedReport().subscribe(
      (res:Reports[]) => {
        this.reports=res;
        console.log(this.reports);
      },
      (err)=>{
        this.error=err;
      }
      );
  }
}

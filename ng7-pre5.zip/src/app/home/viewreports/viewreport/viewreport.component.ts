import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location  } from '@angular/common';
import { Service } from 'src/app/services';
import { Employees } from 'src/app/stages';
import { Reports } from 'src/app/reports';

@Component({
  selector: 'app-viewreport',
  templateUrl: './viewreport.component.html',
  styleUrls: ['./viewreport.component.scss']
})
export class ViewreportComponent implements OnInit {
reportDetail;
nc;
summary;
employees: object;
error;
success;
reports:Reports[];
  constructor(private activatedRoute: ActivatedRoute, 
    private reportDetails: Service,
              private location: Location,
              private emp: Service
  ) { }

  ngOnInit() {

    
    this.getreportDetail();
    this.getemployees();
    this.getreportDetail1();
          }

  getreportDetail(){
    const id= +this.activatedRoute.snapshot.paramMap.get('id');
    this.reportDetails.getReportDetails(id)
    .subscribe(reportsDetail=>this.reportDetail=reportsDetail);
  }

  getreportDetail1(){
    const id= +this.activatedRoute.snapshot.paramMap.get('id');
    this.reportDetails.getReportDetails1(id)
    .subscribe(reportsDetail=>this.nc=reportsDetail);
    console.log(this.nc);
  }
  

  getemployees():void{
    this.emp.getEmployees().subscribe(
      (res: Employees[]) => {
        this.employees = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }
  

  acceptReport(id):void{
    this.resetErrors();
   this.reportDetails.acceptReport(+id).subscribe(
     (res: Reports[]) => {
       this.reports = res;
       this.success="Report successfully accepted";
     },(err)=>{
       this.error=err;
     }
   );
  }

  

  rejectReport(id):void{
    this.resetErrors();
    this.reportDetails.rejectReport(+id).subscribe(
      (res: Reports[]) => {
        this.reports = res;
        this.success="Report successfully Rejected";
      },(err)=>{
        this.error=err;
      }
    );
  }

  onBack(){
    this.location.back();
  } 

  updatereport(projectName,location, projectManager, competency, Lead, 
              qaLead,tracks, auditor,aduitDate, remarks, id,Customer):void {

                this.resetErrors();
                this.reportDetails.updatereport({ id: +id, projectName: projectName.value, location: location.value,projectManager:projectManager.value,
                competency:competency.value,Lead:Lead.value,qaLead:qaLead.value, tracks:tracks.value,auditor:auditor.value,
              aduitDate:aduitDate.value,remarks:remarks.value })
                  .subscribe(
                  (res) => {
                    
                    this.reportDetail = res;
                    
                    this.success = 'Updated successfully';
                  },
                  (err) => this.error = err
                  );
  }


  private resetErrors() {
    this.success = '';
    this.error = '';
  }
}

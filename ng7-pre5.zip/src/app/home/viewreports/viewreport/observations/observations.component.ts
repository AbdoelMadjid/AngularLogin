import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-observations',
  templateUrl: './observations.component.html',
  styleUrls: ['./observations.component.scss']
})
export class ObservationsComponent implements OnInit {

  audit;
  observation;
    constructor(private activatedRoute: ActivatedRoute,   
      private summaryobs: Service,
     ) { }

  ngOnInit() {
    this.getObservation();
  }

  getObservation() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.summaryobs.getObservation(id)
      .subscribe(observations => this.observation = observations);
  }

  Arr = Array;
  nc2;

  addfields(c:any){
    this.nc2 = c;
     console.log(this.nc2);
   }

}


import { Service } from 'src/app/services';
import { Component, OnInit,ViewChild  } from '@angular/core';
import { MatTableDataSource,MatSort,MatPaginator } from '@angular/material';
import { Observable, Subject } from 'rxjs';

import {
  debounceTime, distinctUntilChanged, switchMap
} from 'rxjs/operators';

@Component({
  selector: 'app-viewreports',
  templateUrl: './viewreports.component.html',
  styleUrls: ['./viewreports.component.scss']
})
export class ViewreportsComponent implements OnInit {

  //reports: object;
  constructor(private report: Service) { }
 // dataSource: MatTableDataSource<any>;
  dataSource = new MatTableDataSource();
 displayedColumns: string[] = ['Customer', 'Project', 'Competency', 'Location', 'Audit Date','Tracks'];
  members;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
 
  ngOnInit() {
 
    //return this.report.getReports().subscribe(res => this.dataSource.data = res);
    this.report.getReports()
       .subscribe(report => this.dataSource.data = report);
  }


  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  } 
 
  // getReports() {
  //   this.report.getReports()
  //     .subscribe(report => this.reports = report);
  // }

 
 

}

import { Component, OnInit } from '@angular/core';
import { stages } from 'src/app/stages';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewstages',
  templateUrl: './viewstages.component.html',
  styleUrls: ['./viewstages.component.scss']
})
export class ViewstagesComponent implements OnInit {
  success;
  error;
  stages: object;

  constructor(private stage: Service) { }

  ngOnInit() {
    this.getStages();
  }

  // getStages(){
  //   this.stage.getStages()
  //     .subscribe(stage => this.stages = stage);
  // }


  getStages(): void {
    this.stage.getStages().subscribe(
      (res: stages[]) => {
        this.stages = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }

 

  updatestages(stage_id, stage_name, role_name) {
    this.resetErrors();
    this.stage.updatestage({ stage_id: +stage_id, stage_name: stage_name.value, role_name: role_name.value })
      .subscribe(
      (res) => {
        
        this.stages = res;
        
        this.success = 'Updated successfully';
      },
      (err) => this.error = err
      );
  }




  deletestage(id) {
    this.resetErrors();
    this.stage.deletestage(+id)
      .subscribe(
      (res: stages[]) => {
        this.stages = res;
        this.success = 'Deleted successfully';
      },
      (err) => this.error = err
      );
  }

 

  private resetErrors() {
    this.success = '';
    this.error = '';
  }

}

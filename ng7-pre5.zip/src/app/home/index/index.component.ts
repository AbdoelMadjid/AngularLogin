import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app//services';
import { dashboard } from 'src/app/stages';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.scss']
})
export class IndexComponent implements OnInit {
  users: object;
  dashboard:object;
  dashboard1:object;
  error;
array=[0,1,2,3,4];
  constructor(private data: Service) { }

  ngOnInit() {
    // this.data.getUsers().subscribe(data => {
    //     this.users = data
    //     console.log(this.users);
    //   }
    // );
    this.getdashboard();
  }

  today: number = Date.now();
  getdashboard(): void{
    this.data.getDashoard().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      //  console.log(this.dashboard);
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
 
  
}

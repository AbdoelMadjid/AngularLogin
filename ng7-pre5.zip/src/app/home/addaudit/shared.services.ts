import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators,FormArray,ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private fb:FormBuilder, private http: HttpClient) { }
    Url= "http://192.168.142.25:8080/Systems/api/";
  
  formModel = this.fb.group({
    customer: ['',Validators.required],
    project: ['',Validators.required],
    competency : ['',Validators.required],
    location: ['',Validators.required],
    tracks: ['', Validators.required],
    Lead: ['', Validators.required],
    qaLead: ['', Validators.required],
    projectManager: ['', Validators.required],
    auditor: ['', Validators.required],
    auditDate: ['', Validators.required]
  });


  formModel1 = this.fb.group({
    Lead: ['', Validators.required],
    qaLead: ['', Validators.required],
    projectManager: ['', Validators.required],
    auditor: ['', Validators.required],
    auditDate: ['', Validators.required]
  });

  formModel2 = this.fb.group({
      remarks:['']
  });
  formModel3 = this.fb.group({
     question:[''],
      Evidence:[''],
      Verified:[''],
      Total_Points:[''],
      AttainedPoints:[''],
      exception:[''],
      nc:[''],
      observation:['']
  });


register(){
  var body = {
    customer: this.formModel.value.customer,
    project: this.formModel.value.project,
    competency: this.formModel.value.competency,
    location: this.formModel.value.location,
    tracks: this.formModel.value.tracks,
    Lead: this.formModel1.value.Lead,
    qaLead: this.formModel1.value.qaLead,
    projectManager: this.formModel1.value.projectManager,
    auditor: this.formModel1.value.auditor,
    auditDate: this.formModel1.value.auditDate,
    remarks:this.formModel2.value.remarks,
    question:this.formModel3.value.question,
    Evidence:this.formModel3.value.Evidence,
    Verified:this.formModel3.value.Verified,
    Total_Points:this.formModel3.value.Total_Points,
    AttainedPoints:this.formModel3.value.AttainedPoints,
    exception:this.formModel3.value.exception,
    nc:this.formModel3.value.exception,
    observation:this.formModel3.value.observation

  };
  return this.http.post(this.Url+'test', body)
}


login(formData){
  return this.http.post(this.Url+'/ApplicationUser/Login', formData);
}

getUserProfile(){
    return this.http.get(this.Url+'UserProfile');
}
}

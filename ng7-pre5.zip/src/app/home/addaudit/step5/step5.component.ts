import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormDataService } from '../data/formData.service';
import { step5 } from '../data/formData.model';

@Component({
  selector: 'app-step5',
  templateUrl: './step5.component.html',
  styleUrls: ['./step5.component.scss']
})
export class Step5Component implements OnInit {
  nc1;
  step5: step5;
  form:any;
  constructor(private router:Router, private service: FormDataService) { }

  ngOnInit() {
    this.phases;
    this.step5 = this.service.getstep5();
    console.log('Step4 features loaded!');
  }
Arr = Array;
  addNC(n:any){
   this.nc1 = n;
    console.log(this.nc1);
  }

  phases= ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];

  save(form: any): boolean {
    if(!form.valid){
      return false;
    }
    this.service.setstep5(this.step5);
    return true;
  }
 
  goToNext() {
         this.router.navigate(['/home/newAudit/step6']);
    
  }

  goToPrevious() {
         this.router.navigate(['home/newAudit/step4']);
   
  }

}


import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { step2 } from '../data/formData.model';
import { FormDataService } from '../data/formData.service';
import { Service } from 'src/app/services';
import { Employees } from 'src/app/stages';
import { SharedService } from '../shared.services';
@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.scss']
})
export class Step2Component implements OnInit {
  step2: step2;
  form: any;
  employees: object;
  error;
 
  constructor(private location: Location,private services: SharedService,private router: Router, private emp: Service , private service: FormDataService ) { }

  ngOnInit() {
    this.services.formModel1.reset();
   this.step2=this.service.getstep2();
   console.log('Step2 features loaded!');
    this.getemployees();


  
  }

  save(form:any): boolean{
    this.service.setstep2(this.step2);
    return true
  }

  goToNext(form:any){
    if(this.save(form)){
      this.router.navigate(['home/newAudit/step3']);
    }
  }

  // onSubmit(){
  //   this.services.register().subscribe(
  //       (res: any) => {
  //         if (res.succeeded) {
  //           this.services.formModel.reset();
  //           console.log('New user created!', 'Registration successful.');
  //         } 
  //       },
  //     err => {
  //       console.log(err);
  //     }
  //   );
  // }

  goToPrevious(form:any){
    if(this.save(form)){
      this.router.navigate(['home/newAudit/home']);
    }
  }

  getemployees():void{
    this.emp.getEmployees().subscribe(
      (res: Employees[]) => {
        this.employees = res;
      },
      (err) => {
        this.error = err;
      }
    );
  }
  

}

import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router  } from '@angular/router';
import { basic } from '../data/formData.model';
import { FormDataService } from '../data/formData.service';
import { SharedService } from '../shared.services';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.scss']
})
export class BasicComponent implements OnInit {
  title = 'Please add required details for Audit Report';
  basic: basic;
  form: any;

  constructor(private router: Router, private service: FormDataService,
    private services: SharedService) {
  }

  ngOnInit() {
    this.services.formModel.reset();
    this.basic = this.service.getbasic();
    console.log('basic feature loaded!');
  }
  competency;
  options;
  onChange(co) {
    console.log(co.value);
    if (this.basic.competency === 'Digital') {
      this.options = [
        { name: 'Pleas Select Track' },
        { name: "BPM", value: "BPM" },
        { name: "CRM", value: "CRM" },
        { name: "NutShell", value: "Nutshell" }
      ];
    } else if (this.basic.competency === 'Developing') {
      this.options = [
        { name: 'Pleas Select Track' },
        { name: "Option1", value: "Option1" },
        { name: "Option2", value: "Option2" },
        { name: "Option3", value: "Option3" }
      ];
    } else if (this.basic.competency === 'HR') {

      this.options = [
        { name: 'Pleas Select Track' },
        { name: "Option4", value: "Option4" },
        { name: "Option5", value: "Option5" },
        { name: "Option6", value: "Option6" }
      ];
    }

  }



  save(form: any): boolean {
    this.service.setbasic(this.basic);
    return true;
  }

  goToNext(form: any) {
    if (this.save(form)) {
      // Navigate to the work page
      this.router.navigate(['home/newAudit/step2']);
    }
  }
  }



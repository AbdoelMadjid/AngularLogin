import { Component, OnInit } from '@angular/core';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewreports',
  templateUrl: './viewreports.component.html',
  styleUrls: ['./viewreports.component.scss']
})
export class ViewreportsComponent implements OnInit {

  reports: object;
  constructor(private report: Service) { }

  ngOnInit() {
    this.getReports();
  }

  getReports() {
    this.report.getReports()
      .subscribe(report => this.reports = report);
  }


}

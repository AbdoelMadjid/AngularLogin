import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddauditComponent } from './home/addaudit/addaudit.component';
import { ViewquestionsComponent } from './home/viewquestions/viewquestions.component';
import { ViewreportsComponent } from './home/viewreports/viewreports.component';
import { ViewrolesComponent } from './home/viewroles/viewroles.component';
import { ViewstagesComponent } from './home/viewstages/viewstages.component';
import { ViewreportComponent } from './home/viewreports/viewreport/viewreport.component';
import { ViewchecklistComponent } from './home/viewreports/viewreport/viewchecklist/viewchecklist.component';
import { ViewsummaryComponent  } from './home/viewreports/viewreport/viewsummary/viewsummary.component'
import { BasicComponent } from './home/addaudit/basic/basic.component';
import { Step2Component } from './home/addaudit/step2/step2.component';
import { Step3Component } from './home/addaudit/step3/step3.component';
import { Step4Component } from './home/addaudit/step4/step4.component';
import { Step5Component } from './home/addaudit/step5/step5.component';
import { Step6Component } from './home/addaudit/step6/step6.component';
import { WorkflowGuard } from './home/addaudit/workflow/workflow-guard.service';
import { WorkflowService } from './home/addaudit/workflow/workflow.service';
import { IndexComponent } from './home/index/index.component';
import { PendingauditorsComponent } from './pendingauditors/pendingauditors.component';
import { PendingreportsComponent } from './pendingreports/pendingreports.component';
import { RejectedreportsComponent } from './home/rejectedreports/rejectedreports.component';
const routes: Routes = [
  {path:'', component: LoginComponent,
    data: { title: 'Login - Systems Audit System' }},
  {path:'register', component: RegisterComponent,
    data: { title: 'Register - Systems Audit System' }},
  {path:'home',  component: HomeComponent,
    data: { title: 'Home - Systems' },
    children: [
      {
        path: '', component: IndexComponent,
        data: { title: 'Home - Systems' }
      },
      { 
        path:'newAudit', component: AddauditComponent,
         data: { title: 'Add New Audit - Systems' },
         children: [
           {
             path: 'home', component: BasicComponent,
           },
           {
             path: '', component: BasicComponent,
           },
           {
             path: 'step2', component: Step2Component,
           },
           {
             path: 'step3', component: Step3Component,
           },
           {
             path: 'step4', component: Step4Component,
           },
           {
             path: 'step5', component: Step5Component,
           },
           {
             path: 'step6', component: Step6Component,
           }
         ]
      },      
      {
        path: 'viewreports', component: ViewreportsComponent,
        data: { title: 'Audit Reports - Systems' }
      },
      {
        path: 'viewreport/:id', component: ViewreportComponent,
        data: { title: 'Audit Report - Systems' },
        children: [
          {
          path:'', component: ViewchecklistComponent, pathMatch:'full',
          data: { title: 'Questions List' }
          },
          {
            path: 'viewchecklist', component: ViewchecklistComponent,
            data: { title: 'Questions List' }
          },
          {
            path:'viewsummary/:id', component: ViewsummaryComponent,
            data: { title: 'View Audit Summary' }
          }
        ]
      },
      {
        path:'viewquestions', component: ViewquestionsComponent,
        data: { title: 'Questions List' }
      },
      {
      path:'viewroles', component:ViewrolesComponent,
      data: { title: 'Roles List' }
      },
      {
      path:'viewstages', component:ViewstagesComponent,
      data: { title: 'Stages List' }
      }
      
    ]
},{path:'pendingauditors', component: PendingauditorsComponent,
data: { title: 'Pending Auditors - Systems Audit System' }},
{path:'pendingreports', component: PendingreportsComponent,
    data: { title: 'Pending Reports - Systems Audit System' }},
  {
    path:'rejectedreports', component: RejectedreportsComponent,
    data: { title: 'Rejected Reports - Systems Audit'}
  }
];






@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [WorkflowGuard]
})
export class AppRoutingModule { }

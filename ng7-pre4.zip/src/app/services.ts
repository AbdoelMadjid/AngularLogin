import { Injectable } from '@angular/core';
import { Roles } from './roles';
import { stages, Employees, dashboard, auditors,ncs } from './stages';
import { Questions } from './questions';
import { Reports } from './reports';
import { ReportDetails } from './reportdetails';
import { Summary } from './summary';
import { Auditsummary } from './auditsummary';
import { summaryDetail } from './summarydetail';
import { Observable, throwError, of } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpParams, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Service {

  
  auditor: auditors[];
  dashboard: dashboard[];
  dashboard1: dashboard[];
  roles: Roles[];
  ncs:ncs[];
  jsonObj:object;
  stages: stages[];
  questions: Questions[];
  employees: Employees[];
  reports: Reports[];
  reportDetails: ReportDetails[];
  observations:summaryDetail[];
  summary: Summary[];
  auditsummary: Auditsummary[];
  summarydetail: summaryDetail[];
  Url ='http://localhost:8080/Systems/api/';
  constructor(private http: HttpClient, private router: Router, private location: Location) { }
  // getRoles() {
  //   return this.http.get("https://reqres.in/api/users");
  // }
  // getRoles(): Observable<Roles[]> {
  //   return this.http.get(`${this.Url}/roles`).pipe(
  //     map((res) => {
  //       this.roles = res['data'];
  //       return this.roles;
  //     }),
  //     catchError(this.handleError));
    
  // }

  getRoles(): Observable<Roles[]> {
    return this.http.get(`${this.Url}/roles`).pipe(
      map((res) => {
        this.roles = res['data'];
        // debugger;
        // this.jsonObj=res['data'];
        // debugger;
        // console.log(this.jsonObj);
         return this.roles;
      }),
      catchError(this.handleError));
  }

  getDashoard(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t1`).pipe(
      map((res)=> {
        this.dashboard = res ['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  getloc(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t2`).pipe(
      map((res)=> {
        this.dashboard = res ['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  getst(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t3`).pipe(
      map((res)=> {
        this.dashboard = res ['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  getindvstg(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t4`).pipe(
      map((res)=> {
        this.dashboard = res ['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  getcompetency(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t5`).pipe(
      map((res)=> {
        this.dashboard = res ['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  getstag(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t6`).pipe(
      map((res)=> {
        this.dashboard = res['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }

  
  gettracks(): Observable<dashboard[]>{
    return this.http.get(`${this.Url}t7`).pipe(
      map((res)=> {
        this.dashboard = res['data'];
        return this.dashboard;
      }),
      catchError(this.handleError));
  }
  
  getauditors(): Observable<auditors[]>{
    return this.http.get(`${this.Url}pendingauditors`).pipe(
      map((res)=>{
        this.auditor = res['data'];
        return this.auditor;
        
      }
      ),
      catchError(this.handleError)
    );
  }
 


  acceptauditor(id: number): Observable<auditors[]> {
    const params = new HttpParams()
      .set('id', id.toString());
    
    return this.http.delete(`${this.Url}/acceptauditor?id=${id}`, { params: params })
    
      .pipe(map(res => {
        const filteredrole = this.auditor.filter((auditor) => {
          return +auditor['id'] !== +id;
        });
        return this.auditor = filteredrole;
      }),
      catchError(this.handleError));
  }


  acceptReport(id:number): Observable<Reports[]> {
    const params = new HttpParams()
    .set('id', id.toString());
    return this.http.delete(`${this.Url}acceptReport?id=${id}`, {params: params})

    .pipe(map(res =>{
      const filteredreport = this.reports.filter((reports)=>{
        return +reports['id'] !== +id;
      }); 
      return this.reports = filteredreport;
    }),
      catchError(this.handleError));
  }

  rejectReport(id:number): Observable<Reports[]> {
    const params = new HttpParams().set('id', id.toString());
    return this.http.delete(`${this.Url}rejectReport?id=${id}`, {params: params})

    .pipe(map(res=>{
      const filteredreport = this.reports.filter((reports)=>{
        return +reports['id'] !== +id;
      }); 
      return this.reports = filteredreport;
    }),
      catchError(this.handleError));
  }


  getrejectedReport(): Observable<Reports[]> {
    return this.http.get(`${this.Url}/rejectedReports`).pipe(
      map((res) => {
        this.reports = res['data'];
        return this.reports;
      }),
      catchError(this.handleError));
  }

  

  getStages(): Observable<stages[]> {
    return this.http.get(`${this.Url}/stages`).pipe(
      map((res) => {
        this.stages = res['data'];
        return this.stages;
      }),
      catchError(this.handleError));
  }

  getQuestions(): Observable<Questions[]> {
    return this.http.get(`${this.Url}/questions`).pipe(
      map((res) => {
        
        this.questions = res['data'];
        return this.questions;
      }),
      catchError(this.handleError));
  }

  getEmployees(): Observable<Employees[]>{
    return this.http.get(`${this.Url}/emp`).pipe(
      map((res) => {
        this.employees = res['data'];
        return this.employees;
      }),
      catchError(this.handleError));
  }
  

  getReports(): Observable<Reports[]> {
    return this.http.get(`${this.Url}/reports`).pipe(
      map((res) => {
        this.reports = res['data'];
        return this.reports;
      }),
      catchError(this.handleError));
  }


  getpeningReports(): Observable<Reports[]> {
    return this.http.get(`${this.Url}pendingreports`).pipe(
      map((res) => {
        this.reports = res['data'];
        return this.reports;
      }),
      catchError(this.handleError)
    );

  }

 


  getReportDetails(id: number): Observable<ReportDetails[]> {
   const url = `${this.Url}/reportdetails?id=${id}`;
   return this.http.get<ReportDetails>(url).pipe(
     map((res)=>{
       this.reportDetails = res['data'];
       return this.reportDetails;
     }),
     catchError(this.handleError));
 }

 getReportDetails1(id: number): Observable<ReportDetails[]> {
  const url = `${this.Url}/getncs?id=${id}`;
  return this.http.get<ReportDetails>(url).pipe(
    map((res)=>{
      this.reportDetails = res['data'];
      return this.reportDetails;
    }),
    catchError(this.handleError));
}


  getSummary(id: number): Observable<Summary[]> {
    const url = `${this.Url}/getchecklist?id=${id}`;
   return this.http.get<Summary>(url).pipe(
     map((res)=>{
       this.summary = res['data'];
       return this.summary;
     }),
     catchError(this.handleError));
 }

  

  getauditsummary(id: number): Observable<Auditsummary[]> {
  const url = `${this.Url}/getsummary?id=${id}`;
    return this.http.get<Auditsummary>(url).pipe(
  map((res) => {
    this.auditsummary = res['data'];
    return this.auditsummary;
  }),
  catchError(this.handleError));
  }

  
  getncs(id: number): Observable<ncs[]> {
    const url = `${this.Url}ncs?id=${id}`;
      return this.http.get<ncs>(url).pipe(
    map((res) => {
      this.ncs = res['data'];
      return this.ncs;
      
    }),
    catchError(this.handleError));
    }

  getsummarydetail(id: number): Observable<summaryDetail[]> {
    const url = `${this.Url}/getsummarydetail?id=${id}`;
    
    return this.http.get<summaryDetail>(url).pipe(
      map((res) => {
        this.summarydetail = res['data'];
        return this.summarydetail;
      }),
      catchError(this.handleError));
  }

  getObservation(id: number): Observable<summaryDetail[]> {
    const url = `${this.Url}/getobservation?id=${id}`;
    return this.http.get<summaryDetail>(url).pipe(
      map((res) => {
        this.observations = res['data'];
        return this.observations;
      }),
      catchError(this.handleError));
  }

 

  rejectauditor(id: number): Observable<auditors[]> {
    const params = new HttpParams()
      .set('id', id.toString());
    
    return this.http.delete(`${this.Url}/rejectauditor?id=${id}`, { params: params })
    
      .pipe(map(res => {
        const filteredrole = this.auditor.filter((auditors) => {
          return +auditors['id'] !== +id;
        });
        return this.auditor = filteredrole;
      }),
      catchError(this.handleError));
  }
  

  deleterole(id: number): Observable<Roles[]> {
    const params = new HttpParams()
      .set('id', id.toString());
    
    return this.http.delete(`${this.Url}/deleterole?id=${id}`, { params: params })
    
      .pipe(map(res => {
        const filteredrole = this.roles.filter((role) => {
          return +role['id'] !== +id;
        });
        return this.roles = filteredrole;
      }),
      catchError(this.handleError));
  }


  deletestage(id: number): Observable<stages[]> {
    const params = new HttpParams()
      .set('id', id.toString());

    return this.http.delete(`${this.Url}/deletestage?id=${id}`, { params: params })

      .pipe(map(res => {
        const filteredstage = this.stages.filter((stage) => {
          return +stage['stage_id'] !== +id;
        });
        return this.stages = filteredstage;
      }),
      catchError(this.handleError));
  }


 
  // updaterole(roles: Roles): Observable<Roles[]> {
  //   return this.http.put(`${this.Url}/updateroles`, { data: roles })
  //     .pipe(map((res) => {
  //       const therole = this.roles.find((item) => {
  //         return +item['id'] === +roles['id'];
  //       });
  //       if (therole) {
  //         therole['role_name'] = +roles['role_name'];

  //       }
  //       return this.roles;
  //     }),
  //     catchError(this.handleError));
  // } 


  updaterole(roles: Roles): Observable<Roles[]> {
    return this.http.put(`${this.Url}/updateroles`, roles)
      .pipe(map((res) => {
        const thequestion = this.roles.find((item) => {
          return +item['id'] === +roles['id'];

        });
        console.log(thequestion);
        if (thequestion) {
          thequestion['role_name'] = +roles['role_name'];
          
        }
        return this.roles;
      }),
      catchError(this.handleError));
  }


  updatestage(stages: stages): Observable<stages[]> {
    return this.http.put(`${this.Url}/updatestages`, stages)
      .pipe(map((res) => {
        const thestage = this.stages.find((item) => {
          return +item['id'] === +stages['id'];
        });
        if (thestage) {
          thestage['stage_name'] = stages['stage_name'];
          thestage['role_name'] = +stages['role_name'];

        }
        return this.stages;
      }),
      catchError(this.handleError));
  }


  updatereport(reports: Reports): Observable<Reports[]> {
    return this.http.put(`${this.Url}/updatereport`, reports)
      .pipe(map((res) => {
        const thereport = this.reports.find((item) => {
          return +item['id'] === +reports['id'];
        });
        if (thereport) {
          thereport['id']===+reports['id'];
          thereport['projectName'] = reports['projectName'];
          thereport['location'] = reports['location'];
          thereport['projectManager'] = reports['projectManager'];
          thereport['competency'] = reports['competency'];
          thereport['qaLead'] = reports['qaLead'];
          thereport['tracks'] = reports['tracks'];
          thereport['aduitDate'] = reports['aduitDate'];
          thereport['remarks'] = reports['remarks'];
          thereport['Lead'] = reports['Lead'];
          thereport['Customer'] = reports['Customer'];

        }
        return this.reports;
      }),
      catchError(this.handleError));
  }


  updatequestion(questions: Questions): Observable<Questions[]> {
    return this.http.put(`${this.Url}updatequestion`, questions)
      .pipe(map((res) => {
        const thequestion = this.questions.find((item) => {
          return +item['question_id'] === +questions['question_id'];
       
        });
        if (thequestion) {          
          thequestion['question'] = questions['question'];
          thequestion['Total_Points'] = +questions['Total_Points'];
        }
        return this.questions;
      }),
      catchError(this.handleError));
  }

  deletequestion(id: number): Observable<Questions[]> {
    const params = new HttpParams()
      .set('id', id.toString());

    return this.http.delete(`${this.Url}/deletequestion?id=${id}`, { params: params })

      .pipe(map(res => {
        const filteredquestion = this.questions.filter((question) => {
          return +question['question_id'] !== +id;
        });
        return this.questions = filteredquestion;
      }),
      catchError(this.handleError));
  }

  search(term: string): Observable<Reports[]> {
    if (!term.trim()) {
      // if not search term, return empty hero array.
      return of([]);
    }
    return this.http.get<Reports[]>(`${this.Url}/searchreports?name=${term}`).pipe(
      catchError(this.handleError)
    );
  }



  private log() {
    
  }


  

  private handleError(error: HttpErrorResponse) {
    console.log(error);

    // return an observable with a user friendly message
    return throwError('Error! something went wrong.');
  }

  
}



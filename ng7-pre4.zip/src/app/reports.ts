export class Reports{
    Customer?: string;
    location?: string;
    competency?: string;
    projectName?: string;
    tracks?: string;
    aduitDate?: string;
    id?: number;
    project_total?: number;
    auditor?: string;
    Lead?: string;
    qaLead?: string;
    status?: number;
    projectManager?: string;
    remarks?: string;
   
}
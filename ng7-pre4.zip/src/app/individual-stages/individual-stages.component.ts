import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { dashboard } from '../stages';
@Component({
  selector: 'app-individual-stages',
  templateUrl: './individual-stages.component.html',
  styleUrls: ['./individual-stages.component.scss']
})
export class IndividualStagesComponent implements OnInit {

  constructor(private services:Service) { }
dashboard: any=[];
error;
  ngOnInit() {
    this.getindvstg();
  }
  title="Number of Projects by Individual Process Compliance Percentage";
  height=550;
  width=1200;
  type="ColumnChart";
  options={
    bar: {groupWidth: "95%"},
    legend: { position: "none" }
  };
  view= [0, 1, { calc: 'stringify', sourceColumn: 1, type: 'string', role: 'annotation' }];

  getindvstg(): void{
    this.services.getindvstg().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
}

import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { Reports } from '../reports';

@Component({
  selector: 'app-pendingreports',
  templateUrl: './pendingreports.component.html',
  styleUrls: ['./pendingreports.component.scss']
})
export class PendingreportsComponent implements OnInit {
  reports: Reports[];
  error;
  success;
  constructor(private services: Service) { }

  ngOnInit() {
    this.getreports();
  }

  getreports():void{
    this.services.getpeningReports().subscribe(
      (res:Reports[])=>{
        this.reports = res;
      },
      (err)=>{
        this.error = err;
      }
    )
  }

  acceptReport(id):void{
    this.resetErrors();
   this.services.acceptReport(+id).subscribe(
     (res: Reports[]) => {
       this.reports = res;
       this.success="Report successfully accepted";
     },(err)=>{
       this.error=err;
     }
   );
  }

  

  rejectReport(id):void{
    this.resetErrors();
    this.services.rejectReport(+id).subscribe(
      (res: Reports[]) => {
        this.reports = res;
        this.success="Report successfully Rejected";
      },(err)=>{
        this.error=err;
      }
    );
  }

  private resetErrors() {
    this.success = '';
    this.error = '';
  }
}

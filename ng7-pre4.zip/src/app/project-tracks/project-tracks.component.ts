import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { dashboard } from '../stages';

@Component({
  selector: 'app-project-tracks',
  templateUrl: './project-tracks.component.html',
  styleUrls: ['./project-tracks.component.scss']
})
export class ProjectTracksComponent implements OnInit {
  dashboard: any =[];
error;
  constructor(private services: Service) { }

  ngOnInit() {
    this.gettracks();
  }

  title = 'Projects (Number of Projects by Tracks)';
   type = 'PieChart';
   data = [
      ['Firefox', 45.0],
      ['IE', 26.8],
      ['Chrome', 12.8],
      ['Safari', 8.5],
      ['Opera', 6.2],
      ['Others', 0.7] 
   ];
   columnNames = ['Tracks', 'Projects'];
   options = {          
   };
   width = 1200;
   height = 500;

   gettracks(): void{
    this.services.gettracks().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
        console.log(this.dashboard);
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
}

import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { auditors } from '../stages';

@Component({
  selector: 'app-pendingauditors',
  templateUrl: './pendingauditors.component.html',
  styleUrls: ['./pendingauditors.component.scss']
})
export class PendingauditorsComponent implements OnInit {

  constructor(private service: Service) { }
  auditor: auditors[];
error;
success;
  ngOnInit() {
    this.getauditors();
  }

  getauditors(): void{
    this.service.getauditors().subscribe(
      (res:auditors[]) => {
        this.auditor=res;
        console.log(this.auditor);
      },
      (err)=>{
        this.error=err;
      }
      );
  }

  rejectauditor(id) {
    this.resetErrors();
 this.service.rejectauditor(+id)
   .subscribe(
   (res: auditors[]) => {
     this.auditor = res;
     this.success = 'Deleted successfully';
   },
   (err) => this.error = err
   );
}

acceptauditor(id) {
  this.resetErrors();
this.service.acceptauditor(+id)
 .subscribe(
 (res: auditors[]) => {
   this.auditor = res;
   this.success = 'Deleted successfully';
 },
 (err) => this.error = err
 );
}


private resetErrors() {
  this.success = '';
  this.error = '';
}

}

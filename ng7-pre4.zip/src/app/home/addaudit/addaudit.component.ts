import { Component, OnInit } from '@angular/core';
import { FormDataService } from './data/formData.service';
import { Input } from '@angular/core';

@Component({
  selector: 'app-addaudit',
  templateUrl: './addaudit.component.html',
  styleUrls: ['./addaudit.component.scss']
})
export class AddauditComponent implements OnInit {
  @Input() formData;
  constructor(private formDataService: FormDataService) { }

  ngOnInit() {
    this.formData = this.formDataService.getFormData();
  }

}
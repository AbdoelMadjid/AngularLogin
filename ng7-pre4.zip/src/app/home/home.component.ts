import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { DataService } from '../data.service';
import { dashboard } from '../stages';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  h1Style: boolean = false;
  users: object;
  dashboard:object;
  dashboard1:object;
  error;
array=[0,1,2,3,4];
  constructor(private data: Service) { }

  ngOnInit() {
    // this.data.getUsers().subscribe(data => {
    //     this.users = data
    //     console.log(this.users);
    //   }
    // );
    this.getdashboard();
  }

  today: number = Date.now();
  getdashboard(): void{
    this.data.getDashoard().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      //  console.log(this.dashboard);
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
 
  
}

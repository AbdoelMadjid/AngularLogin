import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewsummary',
  templateUrl: './viewsummary.component.html',
  styleUrls: ['./viewsummary.component.scss']
})
export class ViewsummaryComponent implements OnInit {
audit;
sumDetails;
nc;
  constructor(private activatedRoute: ActivatedRoute,
    private activatedRoutes: ActivatedRoute,
    private audits: Service,
    private ncs: Service,
    private summarydetail: Service,
    private location: Location) { }

  ngOnInit() {
    this.getauditsummary();
    this.getncs();
  }


  getauditsummary() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.audits.getauditsummary(id)
      .subscribe(audit => this.audit = audit);
  }

  getncs() {
    const id = +this.activatedRoutes.snapshot.paramMap.get('id');
    this.ncs.getncs(id)
      .subscribe(nc => this.nc = nc);
       console.log(this.nc);
  }




  onBack() {
    this.location.back();
  }

}

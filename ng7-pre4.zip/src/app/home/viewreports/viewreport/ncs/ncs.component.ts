import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-ncs',
  templateUrl: './ncs.component.html',
  styleUrls: ['./ncs.component.scss']
})
export class NcsComponent implements OnInit {
  audit;
  sumDetails;
    constructor(private activatedRoute: ActivatedRoute,   
      private summarydetail: Service,
     ) { }

  ngOnInit() {
    this.phases;
    this.getsummarydetail();
  }

  getsummarydetail() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.summarydetail.getsummarydetail(id)
      .subscribe(summarydetails => this.sumDetails = summarydetails);
  }
  nc1;
  Arr = Array;
  addNC(n:any){
   this.nc1 = n;
    console.log(this.nc1);
  }

  phases= ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];

}

import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { dashboard } from '../stages';

@Component({
  selector: 'app-projects-roles',
  templateUrl: './projects-roles.component.html',
  styleUrls: ['./projects-roles.component.scss']
})
export class ProjectsRolesComponent implements OnInit {

  constructor(private services: Service) { }

  ngOnInit() {
this.getst();
  } 
  error;
  dashboard: any = [];
  title= "Graph by Roles";
  type="PieChart";
  data=[
    ["Project Management", 66.30],
    ["Software Engineering", 56.40]
  ];
  options={
    pieHole: 0.4
  };
  width=500;
  height=350;

  
  getst(): void{
    this.services.getst().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
}

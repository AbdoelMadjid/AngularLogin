export class Reports{
    Customer: string;
    location: string;
    competency: string;
    projectName: string;
    tracks: string;
    aduitDate: string;
    id: number;
   
}
import { Component, OnInit } from '@angular/core';
import * as CanvasJS from 'src/assets/canvasjs.min';
import { Service } from '../services';
import {dashboard} from '../stages';

@Component({
  selector: 'app-project-stages',
  templateUrl: './project-stages.component.html',
  styleUrls: ['./project-stages.component.scss']
})
export class ProjectStagesComponent implements OnInit {
dataPointss:any;
  constructor(private services: Service) { }

error;

        getstag(): void{
          this.services.getstag().subscribe(
            (res: dashboard[]) => {
              this.dataPointss = res;
              console.log(this.dataPointss);
            },
            (err)=>{
              this.error = err;
            }
            );
          
        }

  ngOnInit() {
    this.getstag();
    let chart = new CanvasJS.Chart("chartContainer", {
      theme: "light2",
      animationEnabled: true,
      exportEnabled: true,
    
      title:{
        text: "Monthly Expense"
      },
      data: [{
        type: "pie",
        showInLegend: true,
        toolTipContent: "<b>{name}</b>: ${y} (#percent%)",
        indexLabel: "{name} - #percent%",
        dataPoints: [
          this.dataPointss
        ]
   }]
    });
      
    chart.render();
   
      }
      
  }
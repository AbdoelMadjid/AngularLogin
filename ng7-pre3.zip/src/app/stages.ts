export class stages{
    stage_id: number;
    stage_name: string;
    role_name: number;
}

export class Employees{
    emp_name: string;
}
export class dashboard{
    audits: number;
    auditors: number;
}
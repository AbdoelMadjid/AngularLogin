import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Service } from 'src/app/services';

@Component({
  selector: 'app-viewsummary',
  templateUrl: './viewsummary.component.html',
  styleUrls: ['./viewsummary.component.scss']
})
export class ViewsummaryComponent implements OnInit {
audit;
sumDetails;
  constructor(private activatedRoute: ActivatedRoute,
    private audits: Service,
    private summarydetail: Service,
    private location: Location) { }

  ngOnInit() {
    this.getauditsummary();
    this.getsummarydetail();
  }


  getauditsummary() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.audits.getauditsummary(id)
      .subscribe(audit => this.audit = audit);
  }

  getsummarydetail() {
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.summarydetail.getsummarydetail(id)
      .subscribe(summarydetails => this.sumDetails = summarydetails);
  }

  onBack() {
    this.location.back();
  }

}

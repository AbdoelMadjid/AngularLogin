import { Component, OnInit } from '@angular/core';
import { FormDataService } from '../data/formData.service';
import { Router } from '@angular/router';
import { step3  } from '../data/formData.model'
@Component({
  selector: 'app-step3',
  templateUrl: './step3.component.html',
  styleUrls: ['./step3.component.scss']
})
export class Step3Component implements OnInit {

step3: step3;
form:any;


  constructor(private router: Router, private service: FormDataService) { }

  ngOnInit() {
    this.step3=this.service.getstep3();
    console.log('Step3 features loaded!');
  }


  save(form:any):boolean{
    this.service.setstep3(this.step3);
    return true;
  }
  goToNext(form:any){
    if(this.save(form)){
      this.router.navigate(['/home/newAudit/step4']);
    }
  }

  goToPrevious(form:any){
    if(this.save(form)){
      this.router.navigate(['home/newAudit/step2']);
    }
  }
}

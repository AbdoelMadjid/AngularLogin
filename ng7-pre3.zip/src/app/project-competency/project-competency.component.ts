import { Component, OnInit } from '@angular/core';
import { Service } from '../services';
import { dashboard } from '../stages';

@Component({
  selector: 'app-project-competency',
  templateUrl: './project-competency.component.html',
  styleUrls: ['./project-competency.component.scss']
})
export class ProjectCompetencyComponent implements OnInit {
dashboard: any =[];
error;
  constructor(private services:Service) { }

  ngOnInit() {
    this.getcompetency();
  }

title="Graph by Competency";
  width=1200;
  height=400;
  options={
    is3D:true
  }

  type="PieChart";
  columnNames = ['Competency', 'Projects'];

  getcompetency(): void{
    this.services.getcompetency().subscribe(
      (res: dashboard[]) => {
        this.dashboard = res;
      },
      (err)=>{
        this.error = err;
      }
      );
    
  }
  
   
}

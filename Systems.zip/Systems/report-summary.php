<?php 

include('config/header.php');
?>
<style>


  body {
  background-color: #f1f1f1;
}
  
#file_export_filter{
  display: none;
}
.dataTables_filter{
  display: none;
}

  table{
    left:50px;
  }

</style>

<br/>
<br/>
<button id="cmd" onclick="myFunction()">generate PDF</button>
<h3 class="h3 text-center" >Audit Reports Details</h3>

<div class="container">
  <div class="row" id="content1">
    <div class="col-8"></div>
    <div class="col-12">


<table class="table text-center table-hover">
  <thead>
  	 	<?php 
  	$id=$_GET['id'];
$query="select * from `audit` where id=$id";
$sql=mysqli_query($connect, $query);
$rows=mysqli_num_rows($sql);
if($rows==1){
	while($row=mysqli_fetch_assoc($sql)){
		$location=$row['location'];
		$competency=$row['competency'];
		$customer=$row['Customer'];
		$track=$row['tracks'];
		$auditDate=$row['aduitDate'];
		$Project=$row['projectName'];
    $id=$row['id'];
    	$projectManager=$row['projectManager'];
    	$lead=$row['Lead'];
    	$qalead=$row['qaLead'];
    	$auditor=$row['auditor'];
    	$nc=$row['Total_NC'];
      $remarks=$row['remarks'];
?>
    <tr>
      <th scope="col" colspan="8" style="text-align:center;">General Information
      <tr>
      <th scope="col" style="text-align:left">Location</th>
      <td style="text-align:left"><?php echo $location;?></td>
      <th scope="col" style="text-align:left">Project Manager</th>
      <td style="text-align:left"><?php echo $projectManager;?></td>
    <tr>
      <th scope="col" style="text-align:left">Competency</th>
      <td style="text-align:left"><?php echo $competency;?></td>
      <th scope="col" style="text-align:left">Development Lead</th>
      <td style="text-align:left"><?php echo $lead;?></td>
      <tr>
      <th scope="col" style="text-align:left">Track</th>
		<td style="text-align:left"><?php echo $track;?></td>
	  <th scope="col" style="text-align:left">QA Lead</th>
		<td style="text-align:left"><?php echo $qalead;?></td>
      <tr>
      <th scope="col" style="text-align:left">Customer</th>
      <td style="text-align:left"><?php echo $customer;?></td>
      <th scope="col" style="text-align:left">Auditor</th>
      <td style="text-align:left"><?php echo $auditor;?></td>
      <tr>
      <th scope="col" style="text-align:left">Project</th>
      <td style="text-align:left"><?php echo $Project;?></td>
      <th scope="col" style="text-align:left">Audit Date</th>
      <td style="text-align:left"><?php echo $auditDate;?></td>
      <tr>
      <th scope="col" colspan="2" style="text-align:left">Number of NC </th>
      <td colspan="2" style="text-align:right"><?php echo $nc;?></td>
      </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr>
      </th>
     
    </tr>
    <tr>
      <th scope="col" colspan="4" style="text-align:left">Remarks</th>   
    </tr>
    <tr>
      <td colspan="4" style="text-align:left"><?php echo $remarks;?></td>      
    </tr>
  </thead>
  <tbody>

    
  <?php	}
}
?> 
    
  </tbody>


</table>

<?php 
      $query="SELECT project_total from check_list where report_id=$id";
      $get=mysqli_query($connect, $query);
      if($get==true){
        $fetch=mysqli_fetch_assoc($get);
        $project_total=$fetch['project_total'];
      }
?>

<h3 class="text-center">Project Process Compliance %  : <?php echo $project_total;?></h3>
<br/>

<table  class="table text-center table-hover">
  <tr>
    <th scope="col" colspan="8" style="text-align:center;">Phase wise compliance</th>
  </tr>
  <tr>
    <th class="text-left">Sr#</th>
    <th class="text-left">Query</th>
    <th class="text-left">Total Points</th>
    <th class="text-left">Points Attained</th>
    <th class="text-left">Number of NC's</th>

  </tr>
<?php 

 
  ?>
  
  
    <?php

    

  $query1="select stages.stage_name,sum(check_list.Total_Points), SUM(check_list.Points_Attained) from audit INNER JOIN check_list INNER JOIN stages where audit.id=check_list.report_id && audit.id=$id && check_list.stage_id =stages.stage_id GROUP By stages.stage_name";



  $sql1=mysqli_query($connect, $query1);
  $rows1=mysqli_num_rows($sql1);
  $sr=0;
  $s=-1;
  if($rows>0){
  while($row1=mysqli_fetch_assoc($sql1)){
    $stage_name=$row1['stage_name'];
    $Total_Points=$row1['sum(check_list.Total_Points)'];
    $Points_Attained=$row1['SUM(check_list.Points_Attained)'];
    $s++;
    $sr++;
$querys="SELECT stages.stage_name, SUM(IF(summary.phase IS NULL, 0, 1)) AS total FROM stages LEFT JOIN summary ON stages.stage_name = summary.phase && summary.report_id = $id GROUP by 1 ORDER by stages.stage_name";



  $sqls=mysqli_query($connect, $querys);
  $rowss=mysqli_num_rows($sqls);
  
  if($rowss>0){
  while($row1s=mysqli_fetch_assoc($sqls)){
    $stages[]=$row1s['stage_name'];
    $Total[]=$row1s['total'];
    
    
}}
   


   

?>
<tr>
    <td style="text-align:left"><?php echo $sr?></td>
    <td style="text-align:left"><?php echo $stage_name;?></td>
    <td style="text-align:left"><?php echo $Total_Points;?></td>
    <td style="text-align:left"><?php echo $Points_Attained;?></td>
    <td style="text-align:left"><?php echo $Total[$s]; ?></td>
  <?php 

}
}

  ?>
  
  </tr>
  

  

</table>
<br/>
<br/>

</div>
</div>
<div class="row">
  <div class="col-8">
  <table class="table text-center table-hover">
    <?php 
    $query2="SELECT * FROM `summary` WHERE `report_id` = $id";
    $sum=mysqli_query($connect, $query2);
    $summary=mysqli_num_rows($sum);
    $se=0;
    if($summary>0){
      while($sumfetch=mysqli_fetch_assoc($sum)){
        $NonConformanceSummary=$sumfetch['NonConformanceSummary'];
        $type=$sumfetch['type'];
        $owner=$sumfetch['owner'];
        $phase=$sumfetch['phase'];
        
        $se++;
     
    ?>
  <tr>
    <th class="text-left">NC# <?php echo $se; ?></th>
  </tr>
  <tr>
    <th class="text-left">Non Conformance Summary</th>
    <td class="text-left"><?php echo $NonConformanceSummary; ?></td>
  </tr>
  <tr>
    <th class="text-left">Type</th>
    <td class="text-left"><?php echo $type; ?></td>
  </tr>
  <tr>
    <th class="text-left">Phase</th>
    <td class="text-left"><?php echo $phase; ?></td>
  </tr>
  <tr>
    <th class="text-left">Owner</th>
    <td class="text-left"><?php echo $owner; ?></td>
  </tr>

<?php 
 }
    }
?>
<br/>
</table>

</div>
</div>

<h4 class="h4">Add More NC's?</h4>
<form method="POST">
<div id="container">
      <br>
      <div class="row" >
      <input type="number" class="form-control"  id="NC" name="NC">
    </div>
   
    <br>
    <div class="row">
      <button class="btn btn-primary" id="filldetails" onclick="addNC()" align="right">Add NC Fields</button>
    </div>
    </div>
    </form>

<br/>
<div class="row">
  <div class="col-8">
    
    <table class="table text-center table-hover">
    <?php 
    $query2="SELECT * FROM `observations` WHERE `report_id` = $id";
    $sum=mysqli_query($connect, $query2);
    $summary=mysqli_num_rows($sum);
    $se=0;
    if($summary>0){
      while($sumfetch=mysqli_fetch_assoc($sum)){
        $Observations=$sumfetch['Observations'];
        
        $se++;
     
    ?>
  
  <tr>
    <th class="text-left">Sr #</th>
    <td class="text-left"><?php echo $se; ?></td>
  </tr>
  <tr>
    <th class="text-left">Observations</th>
    <td class="text-left"><?php echo $Observations; ?></td>
  </tr>
 

<?php 
 }
    }
?>

<br/>
</table>
  </div>

</div>
<br>
<h3 class="h3">Need More Observations?</h3>
<form method="POST">
<div id="containers">
      <br>
      <div class="row">
      <input type="text" id="member" placeholder=" Add Number of Rows for Observations: (max. 10)" class="form-control" name="member" value="">
    </div>
   
    <br>
    <div class="row">
      <button class="btn btn-primary" id="filldetail" onclick="addFields()" style="float: right;">Add Observation</button>
    </div>
    </div>
    </form>

    
</div>
<script>
function myFunction() {
var prtContent = document.getElementById("content1");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.focus();
WinPrint.print();
WinPrint.close();
 }

</script>
<script type="text/javascript">
    function addNC(){
            // Number of inputs to create
            var number = document.getElementById("NC").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("container");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
              var h = document.createElement("H3");
              var t = document.createTextNode("NC# "+(i+1));
              h.appendChild(t);
              container.appendChild(h);
              container.appendChild(document.createElement("br"));
                // Append a node with a random text
                container.appendChild(document.createTextNode("Non Conformance Summary " + (i+1)));
                            container.appendChild(document.createElement("br"));
                // Create an <input> element, set its type and name attributes
                var input1 = document.createElement("input");
                input1.type = "text";
                input1.name = "NonConformanceSummary[]";
                input1.className = "form-control";
                container.appendChild(input1);
                container.appendChild(document.createElement("br"));
                 // ======================================
                container.appendChild(document.createTextNode("Type " + (i+1)));
                container.appendChild(document.createElement("br"));
                var input2 = document.createElement("input");
                input2.type = "text";
                input2.name= "type[]";
                input2.className = "form-control";
                container.appendChild(input2);
                // =========================================
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Owner " + (i+1)));
                container.appendChild(document.createElement("br"));
                var input3 = document.createElement("input");
                input3.type = "text";
                input3.name = "owner[]";
                input3.className = "form-control";
                container.appendChild(input3);
                // =========================================
                // Append a line break 
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Phase"+(i+1)));
                container.appendChild(document.createElement("br"));
                var input4 = document.createElement("select");
                input4.name="phase[]";
                input4.className = "form-control";
                container.appendChild(input4);                
                var options = ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];
                //====================================
              
                //Create and append the options
                for (var op = 0; op < options.length; op++) {
                    var option = document.createElement("option");
                    option.value = options[op];
                    option.text = options[op];
                    input4.appendChild(option);
                }
                
                container.appendChild(document.createElement("hr"));
            }
              container.appendChild(document.createElement("br"));
                var submit = document.createElement("input");
                submit.type="submit";
                submit.name="nc";
                submit.className = "btn btn-primary";
                container.appendChild(submit);
        }


   function addFields(){
            // Number of inputs to create
            var number = document.getElementById("member").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("containers");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
                // Append a node with a random text
                container.appendChild(document.createTextNode("Observations" + (i+1)));
                                container.appendChild(document.createElement("br"));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                
                input.type = "text";
                input.name = "Observations[]";
               input.className = "form-control";
                container.appendChild(input);
                // Append a line break 
                container.appendChild(document.createElement("br"));

            }
            var submit = document.createElement("input");

                submit.type="submit";
                submit.name="submit";
                submit.className = "btn btn-primary";
                container.appendChild(submit);
        }
</script>

<?php 
if(isset($_POST['submit'])){
$Observations=$_POST['Observations'];
if(count($Observations)>=1){
          $l=0;
          while($l<count($Observations)){

                $query3="INSERT INTO `observations`(`report_id`,`Observations`) VALUES('$id','$Observations[$l]');";
            
            $l++;
            if(mysqli_query($connect,$query3)==true){

            }else{
              echo $query3;
            }
        }
}
 
}




?>
  

<br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>

<?php 
include('config/footer.php');
 ?>
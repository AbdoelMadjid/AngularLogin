<?php
session_start();
include('config.php');
    $post_id = $_GET['id'];
                $veh_query = $connect->query("UPDATE  tbl_login SET 
                                                            
                                                                status='2'
                                                                WHERE id='$post_id'");
                            
                            if ($veh_query == TRUE) {
                            
                            
                            
                                                            
                                    ?>
                                 <script>window.location = "../pendingusers";</script>
                                 <?php
                                } else {
                                
                                    echo "<script>alert('Error')</script>";
                                                          
                                }
?>
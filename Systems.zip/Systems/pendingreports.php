<?php 
include('config/header.php');
?>
<style type="text/css">
  body {
  background-color: #f1f1f1;
}

</style>
<?php 
if(isset($_POST['approve'])){
  echo "approve";
}elseif(isset($_POST['reject'])){
  echo "reject";
}
?>


<br/>
<br/>
<br/>
<h3 class="h3 text-center" >Pending Audit Reports</h3>
<br>
<br>
<div class="auth-wrapper no-block justify-content-center align-items-center">
	<div class="row">
		<div class="col-1"></div>
<div class="col-10">


<br>
<table id="myTable1" class="table text-center table-hover">
  <thead>
    <tr>
       <th scope="col">Customer</th>
      <th scope="col">Location</th>
      <th scope="col">Competency</th>
      <th scope="col">Project</th>
      <th scope="col">Tracks</th>
      <th scope="col">Audit Date</th>
      <th scope="col">Project Total</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody id="myTable">
  	<?php 
$query="SELECT *, check_list.project_total from audit INNER JOIN check_list where audit.status=0 && audit.id = check_list.report_id GROUP by check_list.report_id";
$sql=mysqli_query($connect, $query);
$rows=mysqli_num_rows($sql);
if($rows>0){
  while($row=mysqli_fetch_assoc($sql)){
    $location=$row['location'];
    $competency=$row['competency'];
    $customer=$row['Customer'];
    $Project=$row['projectName'];
    $auditDate=$row['aduitDate'];
    $tracks=$row['tracks'];
    $id=$row['id'];
    $total=$row['project_total'];
    $status=$row['status'];
?>
    <tr class="tr">
      <th scope="row"><a style="color:black;" href="view-report?id=<?php echo $id;?>"><?php echo $customer;?></a></th>
      <td><?php echo $location;?></td>
      <td><?php echo $competency;?></td>
      <td><?php echo $Project;?></td>
      
      <td><?php echo $tracks;?></td>
     <td><?php echo $auditDate;?></td>
     <td><?php echo $total; ?></td>
     <td><?php 
if($status==0){
  ?>

<a href="config/approve?id=<?php echo $id; ?>" onclick="return confirm('Are you sure you want to approve this Report ?');"><button type="button" class="btn waves-effect waves-light btn-success">Accept</button></a>
                                        <a href="config/reject?id=<?php echo $id; ?>" onclick="return confirm('Are you sure you want to reject this Report ?');"><button type="button" class="btn waves-effect waves-light btn-danger">Reject</button></a>
                                      <?php } ?></td>
     
      </tr>
  <?php	}
}
?> 
    
  </tbody>





</table>
</div>
<div class="col-10"></div>
</div>
</div>
<br/>
<br/>

<script>

function tableStripes() {
var aTR=document.getElementById('myTable').getElementsByTagName('tr');
for(var i=0, count=1; i<aTR.length; i++) {
    if(aTR[i].style.display!='none') {

     var table = document.getElementById("myTable"), avgVal, sumVal = 0, 
       rowCount = table.rows.length;// minus the header
            
    for(var i = 0; i < table.rows.length; i++)
    if(table.rows[i].style.display!='none'){
   {
      sumVal = sumVal + parseInt(table.rows[i].cells[6].innerHTML);
    }}
            
     document.getElementById("val").innerHTML =  parseInt(sumVal / rowCount);

        count++;   

        }
    }
} 


  
</script>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>



<?php 
include('config/footer.php');
 ?>
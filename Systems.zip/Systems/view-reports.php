<?php 
include('config/header.php');
?>
<style type="text/css">
  body {
  background-color: #f1f1f1;
}

</style>
<?php

       ?>

<br/>
<br/>
<br/>
<h3 class="h3 text-center" >Over All Compliance <span id="val"></span> </h3>

<div class="auth-wrapper no-block justify-content-center align-items-center">
  <div class="row">
    <div class="col-1"></div>
<div class="col-10">

Filter By:<br><br> 
  Location <select id="myInput" name="location" id="location">
  <option value="">---Please Select--</option>
  <option value="Karachi">Karachi</option>
  <option value="Lahore">Lahore</option>
 
</select>
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
  Competency <select id="myInput1" name="competency" id="competency">
  <option value="">---Please Select--</option>
  <option value="Digital Framework">Digital Framework</option>
  <option value="Technology Service">Technology Service</option>
  <option value="Digital Ecommerce">Digital Ecommerce</option>
  <option value="Enterprise Services">Enterprise Services</option>
</select>
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
Tracks <select id="myInput2" name="tracks" id="tracks">
  <option value="">---Please Select--</option>
  <option value="BPM">BPM</option>
  <option value="Test">Test</option>
</select>
<br>
<br>







   <div class="row">
                    <div class="col-12">
            <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="file_export" class="table table-striped table-bordered display">
                                        <thead>
                                            <tr>
                                            <th scope="col">Customer</th>
                                            <th scope="col">Location</th>
                                            <th scope="col">Competency</th>
                                            <th scope="col">Project</th>
                                            <th scope="col">Tracks</th>
                                            <th scope="col">Audit Date</th>
                                            <th scope="col">Project Total</th>
                                            </tr>
                                          </thead>
                                          <tbody id="myTable">
                                            <?php 
                                              $query="SELECT *, check_list.project_total from audit INNER JOIN check_list where audit.status=1 && audit.id = check_list.report_id GROUP by check_list.report_id";
                                              $sql=mysqli_query($connect, $query);
                                              $rows=mysqli_num_rows($sql);
                                              if($rows>0){
                                                while($row=mysqli_fetch_assoc($sql)){
                                                  $location=$row['location'];
                                                  $competency=$row['competency'];
                                                  $customer=$row['Customer'];
                                                  $Project=$row['projectName'];
                                                  $auditDate=$row['aduitDate'];
                                                  $tracks=$row['tracks'];
                                                  $id=$row['id'];
                                                  $total=$row['project_total'];
                                                     
                                              ?>
                                                 
                                           
                                            <tr>
                                              <th scope="row"><a style="color:black;" href="view-report?id=<?php echo $id;?>"><?php echo $customer;?></a></th>
                                              <td><?php echo $location;?></td>
                                              <td><?php echo $competency;?></td>
                                              <td><?php echo $Project;?></td>
                                              
                                              <td><?php echo $tracks;?></td>
                                             <td><?php echo $auditDate;?></td>
                                             <td><?php echo $total; ?></td>
                                              </tr>
                                          <?php }
                                        }
                                        ?> 
                                            
                                          </tbody>


                                        </table>
                                  </div>
                            </div>
                        </div>
                    </div>
                </div>























<script>
$(document).ready(function(){
  $("#myInput").on("change", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput1").on("change", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {


      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

$(document).ready(function(){
  $("#myInput2").on("change", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {

       $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


<script type="text/javascript">
    function CountRows() {
        var totalRowCount = 0;
        var rowCount = 0;
        var table = document.getElementById("myTable");
        var rows = table.getElementsByTagName("tr")
        for (var i = 0; i < rows.length; i++) {
            totalRowCount++;
            if (rows[i].getElementsByTagName("td").length > 0) {
                rowCount++;
            }
        }
        var message = "Total Row Count: " + totalRowCount;
        message += "\nRow Count: " + rowCount;
        alert(message);
    }
</script>

<script>
  




  var table = document.getElementById("myTable"), avgVal, sumVal = 0, 
       rowCount = table.rows.length;// minus the header
            
    for(var i = 0; i < table.rows.length; i++)
   {
      sumVal = sumVal + parseInt(table.rows[i].cells[6].innerHTML);
    }
            
     document.getElementById("val").innerHTML =  parseInt(sumVal / rowCount);
</script>
 
</div>
<div class="col-1"></div>
</div>
</div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>



<?php 
include('config/footer.php');
 ?>
<?php include('config/header.php');
?>
 <style type="text/css">
        .hide,.canvasjs-chart-credit{
             display:none !important;
        }             
    </style>
<br/>

<div class="container-fluid">


                <!-- ============================================================== -->
                <!-- Info box -->
                <!-- ============================================================== -->
          <div class="row">

          	<?php 
          	$query1="SELECT roles.role_name, (SUM(check_list.Points_Attained)/sum(check_list.Total_Points))*100 as result from audit INNER JOIN check_list INNER JOIN stages INNER JOIN roles where audit.status=1 && audit.id=check_list.report_id && check_list.stage_id =stages.stage_id && stages.role_id = roles.role_id GROUP By roles.role_name ORDER BY stages.stage_id";
          	$result1=mysqli_query($connect, $query1);

          	$query2="SELECT audit.competency, COUNT(audit.id) as total from audit WHERE status=1 GROUP by competency";
          	$result2=mysqli_query($connect, $query2);
          	$query3="SELECT tracks, COUNT(id) as total from audit where status=1 GROUP by tracks";
          	$result3=mysqli_query($connect, $query3);
          	$query4="SELECT stages.stage_name, ROUND(((SUM(check_list.Points_Attained)/sum(check_list.Total_Points))*100)/11,2) as total from audit INNER JOIN check_list INNER JOIN stages where audit.status=1 && audit.id=check_list.report_id && check_list.stage_id =stages.stage_id GROUP By stages.stage_name ORDER BY stages.stage_id";
          	$result4=mysqli_query($connect, $query4);
            $query10="SELECT stages.stage_name, ROUND(((SUM(check_list.Points_Attained)/sum(check_list.Total_Points))*100),2) as total from audit INNER JOIN check_list INNER JOIN stages where audit.status=1 && audit.id=check_list.report_id && check_list.stage_id =stages.stage_id GROUP By stages.stage_name ORDER BY stages.stage_id";
             $result10=mysqli_query($connect, $query10); 

          	$query5="SELECT customer,projectName,location,competency,tracks FROM `audit` where status = 1 ORDER by id DESC limit 5";
          	$result5=mysqli_query($connect,$query5);
          	$query6="SELECT * FROM audit";
          	$query7="SELECT * FROM audit where status=1";
          	$query8="SELECT * FROM tbl_login where status=1";
			$query9 = "SELECT location, count(location) as loc FROM `audit` where status=1 GROUP by location";
			$check_location=mysqli_query($connect,$query9);     
          	$check_result=mysqli_query($connect,$query6);        
               // Return the number of rows in result set
            $check_rowcount=mysqli_num_rows($check_result);             
            $check_result1=mysqli_query($connect,$query7);         
               // Return the number of rows in result set
            $check_rowcount1=mysqli_num_rows($check_result1);
            $check_result2=mysqli_query($connect,$query8);         
               // Return the number of rows in result set
            $check_rowcount2=mysqli_num_rows($check_result2);
            
          ?>
                                       
                                                     
                          

     	                
         
                    <div class="col-lg-12">
                        <div class="card  bg-light no-card-border">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    
                                    <div>
                                        <h3 class="m-b-0">Welcome back! <?php echo $_SESSION["fname"].' '.$_SESSION['lname']; ?></h3>
                                        
                                        <span><?php echo date("l");?>, <?php echo date("d F Y");?></span>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

<br/>
<div class="ecommerce-widget">

                        <div class="row">
                            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Total Reports</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $check_rowcount; ?></h1>
                                        </div>
                                        
                                    </div>
                                    <div id="sparkline-revenue"></div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Total Registered Auditors</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $check_rowcount2; ?></h1>
                                        </div>
                                        
                                    </div>
                                    <div id="sparkline-revenue2"></div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="text-muted">Total Approved Reports</h5>
                                        <div class="metric-value d-inline-block">
                                            <h1 class="mb-1"><?php echo $check_rowcount1; ?></h1>
                                        </div>
                                        
                                    </div>
                                    <div id="sparkline-revenue3"></div>
                                </div>
                            </div>
                            
                        </div>
<br/>
<br/>
<br/>




</div>

<div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">Recent Approved Reports</h5>
                                    <div class="card-body p-0">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead class="bg-light">
                                                    <tr class="border-0">
                                                            <th class="border-0">#</th>
                                                        <th class="border-0">Customer</th>
                                                        <th class="border-0">Project Name</th>
                                                        <th class="border-0">Region</th>
                                                        <th class="border-0">Competency</th>
                                                        <th class="border-0">Track</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                	                          	<?php 
                                                    	$sr=1;
                                                    	while($row2 = mysqli_fetch_array($result5))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$customer = $row2['customer'];
            	$projectName = $row2['projectName'];
            	$location = $row2['location'];
            	$competency = $row2['competency'];
            	$tracks = $row2['tracks'];

            
         ?>
         
          
                      
                                                    <tr>
                                                        <td><?php echo $sr;?></td>
                                                        <td>
                                                            <?php echo $customer;?>
                                                        </td>
                                                        <td><?php echo $projectName;?> </td>
                                                        <td><?php echo $location;?> </td>
                                                        <td><?php echo $competency;?></td>
                                                        <td><?php echo $tracks;?></td>
                                                        
                                                    </tr>
                                       <?php } ?>                                                           
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
<br>
<br>
                             <div class="row">
                             	
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Projects (Cities and Number of Projects)</h5>
                                <div class="card-body">
                                     <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Location", "Projects", { role: "style" } ],
		<?php while($loc = mysqli_fetch_array($check_location))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$options = $loc['location'];
            	$options2 = $loc['loc'];
            
         ?>
        ["<?php echo $options;?>", <?php echo $options2;?>, "blue"],
		 <?php } ?> 
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Projects (Cities and Number of Projects)",
        width: 500,
        height: 350,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  }
  </script>
<div id="columnchart_values" style="width: 400px; height: 350px;"></div>

										

                                    <div class="text-center">
                                        <span class="legend-item mr-3">
                                                <span class="fa-xs text-secondary mr-1 legend-tile"><i class="fa fa-fw fa-square-full"></i></span>
                                        <span class="legend-text">Projects (Cities and Number of Projects)</span>
                                        </span>
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end earnings before interest tax  -->
                        <!-- ============================================================== -->

                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Projects (Number of Projects by Process Compliance)</h5>
                                <div class="card-body">
                                    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Roles', 'Percentage'],

          <?php while($row2 = mysqli_fetch_array($result1))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$options = $row2['role_name'];
            	$options2 = $row2['result'];
            
         ?>
         
           ['<?php echo $options;?>',<?php echo $options2;?>],
          <?php } ?> 
        ]);

        var options = {
          title: 'Graph by Process Compliance',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
 
    <div id="donutchart" style="width: 600px; height: 390px;"></div>

                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- cost of goods  -->
                        <!-- ============================================================== -->
                        

</div>
<br>
<br>

                    <div class="row">
  
  <div class="col-xl-12 col-lg-12 col-md-8 col-sm-12 col-12">
                            <div class="card">
                                    <h5 class="card-header">Reports (Number of Projects by Individual Process Compliance)</h5>
                                <div class="card-body" align="center">
                                  
   <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Stages", "Percentage", { role: "style" } ],

        <?php while($row2 = mysqli_fetch_array($result10))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
              $options = $row2['stage_name'];
              $options2 = $row2['total'];
            
         ?>
  ["<?php echo $options;?>", <?php echo $options2;?>, "#blue"],
<?php }?>
        
        
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Number of Projects by Individual Process Compliance Percentage",
        width: 700,
        height: 550,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values1"));
      chart.draw(view, options);
  }
  </script>
<div id="columnchart_values1" style="display: inline-block; width: 700px; height: 550px;"></div>
                            
                            </div>
                        </div>
  
                    </div>
                    
</div>
<div class="row">
	<br>
	<br>
	<div class="col-xl-12 col-lg-12 col-md-8 col-sm-12 col-12">
                            <div class="card">
                               	<h5 class="card-header">Projects (Number of Projects by Competency)</h5>
                                <div class="card-body">

                                    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Competency', 'Projects'],
         <?php while($row2 = mysqli_fetch_array($result2))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$options = $row2['competency'];
            	$options2 = $row2['total'];
            
         ?>
         
           ['<?php echo $options;?>',<?php echo $options2;?>],
          <?php } ?> 
        ]);






        var options = {
          title: 'Graph by Competency',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>
  
    <div id="piechart_3d" style="width: 1200px; height: 400px;"></div>
                                </div>
                            
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end cost of goods  -->
                        <!-- ============================================================== -->
                    </div>


             <div class="row">
             	<div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
                                <div class="card">
                                    <h5 class="card-header">Projects (Number of Projects by Stages)</h5>
                    



<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	exportEnabled: true,
	animationEnabled: true,
	title:{
		text: "Projects By Stages"
	},
	legend:{
		cursor: "pointer",
		itemclick: explodePie
	},
	data: [{
		type: "pie",
		showInLegend: true,
		toolTipContent: "{name}: <strong>{y}%</strong>",
		indexLabel: "{name} - {y}%",
		dataPoints: [
			<?php while($row2 = mysqli_fetch_array($result4))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$options = $row2['stage_name'];
            	$options2 = $row2['total'];
            
         ?>
         
           {name: '<?php echo $options;?>',y:<?php echo $options2;?>},
          <?php } ?> 
		]
	}]
});
chart.render();
}

function explodePie (e) {
	if(typeof (e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
	} else {
		e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
	}
	e.chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 600px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
                                </div>
                            </div>

                                </div>
                            
                            </div>
                        </div>
	
                    </div>







                            <div class="row">
	
	<div class="col-xl-12 col-lg-12 col-md-8 col-sm-12 col-12">
                            <div class="card">
                               	   	<h5 class="card-header">Projects (Number of Projects by Tracks)</h5>
                                <div class="card-body">
                                  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = new google.visualization.DataTable();
      data.addColumn('string', 'Pizza');
      data.addColumn('number', 'Populartiy');
      data.addRows([
        <?php while($row2 = mysqli_fetch_array($result3))
            {
             //  $options = $options."<option>$row2[1]</option>";
              //  $options2 = $options2."$row2[0]";
            	$options = $row2['tracks'];
            	$options2 = $row2['total'];
            
         ?>
         
           ['<?php echo $options;?>',<?php echo $options2;?>],
          <?php } ?> 
      ]);

      var options = {
        title: 'Projects by Tracks',
        sliceVisibilityThreshold: .1
      };

      var chart = new google.visualization.PieChart(document.getElementById('pacman'));
      chart.draw(data, options);
    }
    </script>
    
    <div id="pacman" style="width: 900px; height: 500px;margin-left:auto;
margin-right:auto;"></div>
                                </div>
                            
                            </div>
                        </div>
	
                    </div>




<?php include('config/footer.php');?>
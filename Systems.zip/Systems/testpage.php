<?php 

include('config/header.php');
?>
<style>


  body {
  background-color: #f1f1f1;
}
  
#file_export_filter{
  display: none;
}
.dataTables_filter{
  display: none;
}

  table{
    left:50px;
  }

</style>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.18/b-1.5.6/b-flash-1.5.6/datatables.min.css"/>
 
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.18/b-1.5.6/b-flash-1.5.6/datatables.min.js"></script>
<div id="customers">
<br/>
<br/>
<h3 class="h3 text-center" >Audit Reports Details</h3>

<div class="container">
  <div class="row">
    <div class="col-12">



<table id="content1" class="table table-striped table-bordered display">
  <thead>
  	 	<?php 
  	$id=$_GET['id'];
$query="select * from `audit` where id=$id";
$sql=mysqli_query($connect, $query);
$rows=mysqli_num_rows($sql);
if($rows==1){
	while($row=mysqli_fetch_assoc($sql)){
		$location=$row['location'];
		$competency=$row['competency'];
		$customer=$row['Customer'];
		$track=$row['tracks'];
		$auditDate=$row['aduitDate'];
		$Project=$row['projectName'];
    $id=$row['id'];
    	$projectManager=$row['projectManager'];
    	$lead=$row['Lead'];
    	$qalead=$row['qaLead'];
    	$auditor=$row['auditor'];
    	$nc=$row['Total_NC'];
      $remarks=$row['remarks'];
?>

    <tr>
      <th scope="col" colspan="8" style="text-align:center;">General Information
      <tr>
      <th scope="col" style="text-align:left">Location</th>
      <td style="text-align:left"><?php echo $location;?></td>
      <th scope="col" style="text-align:left">Project Manager</th>
      <td style="text-align:left"><?php echo $projectManager;?></td>
      <tr>
      <th scope="col" style="text-align:left">Competency</th>
      <td style="text-align:left"><?php echo $competency;?></td>
      <th scope="col" style="text-align:left">Development Lead</th>
      <td style="text-align:left"><?php echo $lead;?></td>
      <tr>
      <th scope="col" style="text-align:left">Track</th>
		  <td style="text-align:left"><?php echo $track;?></td>
	     <th scope="col" style="text-align:left">QA Lead</th>
		  <td style="text-align:left"><?php echo $qalead;?></td>
      <tr>
      <th scope="col" style="text-align:left">Customer</th>
      <td style="text-align:left"><?php echo $customer;?></td>
      <th scope="col" style="text-align:left">Auditor</th>
      <td style="text-align:left"><?php echo $auditor;?></td>
      <tr>
      <th scope="col" style="text-align:left">Project</th>
      <td style="text-align:left"><?php echo $Project;?></td>
      <th scope="col" style="text-align:left">Audit Date</th>
      <td style="text-align:left"><?php echo $auditDate;?></td>
      <tr>
      <th scope="col" colspan="2" style="text-align:left">Number of NC </th>
      <td colspan="2" style="text-align:right"><?php echo $nc;?></td>
      </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr>
  </tr> <tr>
      <th scope="col" colspan="4" style="text-align:left">Remarks</th>   
    </tr>
    <tr>
      <td colspan="4" style="text-align:left"><?php echo $remarks;?></td>      
    </tr>
     </div>
<div id="editor"></div>

  </thead>
  <tbody>
<button id="cmd" onclick="myFunction()">generate PDF</button>
    
  <?php	}
}
?> 
    
  </tbody>


</table>
<script>
function myFunction() {
  window.print();
}
</script>
</div>
</div>
</div>




<script type="text/javascript">


    function addNC(){
            // Number of inputs to create
            var number = document.getElementById("NC").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("container");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
              var h = document.createElement("H3");
              var t = document.createTextNode("NC# "+(i+1));
              h.appendChild(t);
              container.appendChild(h);
              container.appendChild(document.createElement("br"));
                // Append a node with a random text
                container.appendChild(document.createTextNode("Non Conformance Summary " + (i+1)));
                            container.appendChild(document.createElement("br"));
                // Create an <input> element, set its type and name attributes
                var input1 = document.createElement("input");
                input1.type = "text";
                input1.name = "NonConformanceSummary[]";
                input1.className = "form-control";
                container.appendChild(input1);
                container.appendChild(document.createElement("br"));
                 // ======================================
                container.appendChild(document.createTextNode("Type " + (i+1)));
                container.appendChild(document.createElement("br"));
                var input2 = document.createElement("input");
                input2.type = "text";
                input2.name= "type[]";
                input2.className = "form-control";
                container.appendChild(input2);
                // =========================================
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Owner " + (i+1)));
                container.appendChild(document.createElement("br"));
                var input3 = document.createElement("input");
                input3.type = "text";
                input3.name = "owner[]";
                input3.className = "form-control";
                container.appendChild(input3);
                // =========================================
                // Append a line break 
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createTextNode("Phase"+(i+1)));
                container.appendChild(document.createElement("br"));
                var input4 = document.createElement("select");
                input4.name="phase[]";
                input4.className = "form-control";
                container.appendChild(input4);                
                var options = ["Project Initiation","Project Planning","Project Monitoring","Requirement Analysis","Requirement Analysis","Change Management","Technical Design","Code Writing","Unit Testing","Internal Release","Test Planning & Designing","QA Acceptance & System Testing"];
                //====================================
              
                //Create and append the options
                for (var op = 0; op < options.length; op++) {
                    var option = document.createElement("option");
                    option.value = options[op];
                    option.text = options[op];
                    input4.appendChild(option);
                }
                
                container.appendChild(document.createElement("hr"));
            }
              container.appendChild(document.createElement("br"));
                var submit = document.createElement("input");
                submit.type="submit";
                submit.name="nc";
                submit.className = "btn btn-primary";
                container.appendChild(submit);
        }


   function addFields(){
            // Number of inputs to create
            var number = document.getElementById("member").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("containers");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
            for (i=0;i<number;i++){
                // Append a node with a random text
                container.appendChild(document.createTextNode("Observations" + (i+1)));
                                container.appendChild(document.createElement("br"));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                
                input.type = "text";
                input.name = "Observations[]";
               input.className = "form-control";
                container.appendChild(input);
                // Append a line break 
                container.appendChild(document.createElement("br"));

            }
            var submit = document.createElement("input");

                submit.type="submit";
                submit.name="submit";
                submit.className = "btn btn-primary";
                container.appendChild(submit);
        }
</script>

<?php 
if(isset($_POST['submit'])){
$Observations=$_POST['Observations'];
if(count($Observations)>=1){
          $l=0;
          while($l<count($Observations)){

                $query3="INSERT INTO `observations`(`report_id`,`Observations`) VALUES('$id','$Observations[$l]');";
            
            $l++;
            if(mysqli_query($connect,$query3)==true){

            }else{
              echo $query3;
            }
        }
}
 
}




?>
  

<br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>
 <br>

<?php 
include('config/footer.php');
 ?>